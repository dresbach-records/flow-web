# FLOW — Pacote de documentação

Arquivos:

- `FLOW_ENGENHARIA.md` — estudo de engenharia e arquitetura.
- `FLOW_INVENTARIO_MODULOS.csv` — inventário de módulos.
- `FLOW_INVENTARIO_MODULOS.json` — inventário estruturado.
- `FLOW_TELAS_COMPONENTES_BASE.csv` — matriz inicial tela/componente/backend.
- `FLOW_TELAS_COMPONENTES_BASE.json` — mesma matriz em JSON.

**Importante:** os arquivos oficiais do catálogo de 350 telas enviados anteriormente expiraram e não estão disponíveis para leitura nesta sessão. A matriz de telas acima é uma base de engenharia; não deve ser tratada como substituta do catálogo oficial. Para gerar o inventário definitivo das 350 telas, reenvie o catálogo/manifesto/inventário oficial.
