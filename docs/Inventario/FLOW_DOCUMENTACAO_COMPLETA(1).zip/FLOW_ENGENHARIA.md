# FLOW — Estudo de Engenharia e Arquitetura
## Admin/RH + Developer Center + Advertising + Billing/Fiscal + Firebase + Stripe

**Versão:** 1.0  
**Data:** 2026-09-04  
**Status:** Arquitetura de referência para implementação  
**Fonte:** requisitos fornecidos no projeto + validação técnica da documentação atual da Stripe/Firebase.

---

## 1. Objetivo

Projetar a infraestrutura operacional da FLOW para que website, rede social, contas de anúncio, pagamentos, fiscal, RH/Admin e Developer Center funcionem como módulos independentes, componíveis, auditáveis e controláveis.

A regra central é:

> O layout não implementa negócio. O layout roteia e compõe páginas. Cada página importa módulos e componentes. Cada componente mantém seu próprio CSS, tipos, testes e contrato.

A aplicação deve ser PWA, responsiva e multiplataforma. Funcionalidades reais não podem depender de dados mockados em produção.

---

## 2. Princípios arquiteturais

1. Modularização por domínio.
2. Componentização obrigatória.
3. CSS co-localizado por componente.
4. Layouts sem lógica de negócio.
5. Backend como autoridade para regras críticas.
6. Firebase como infraestrutura principal.
7. Stripe como infraestrutura de pagamentos/billing quando aplicável.
8. Ledger interno como registro financeiro da FLOW.
9. Webhooks idempotentes.
10. RBAC + regras de acesso no backend.
11. Feature Flags para desligamento controlado de módulos.
12. Auditoria de operações críticas.
13. Estados explícitos: loading, empty, error, success, disabled, unauthorized, forbidden, offline.
14. Nada de saldo, pagamento, usuário ou campanha inventados no frontend.
15. Produção protegida por branch/CI/CD/auditoria.
16. Integrações externas isoladas por adapters/providers.

---

## 3. Macroarquitetura

```text
FLOW
├── Website
├── Social
├── Workspace
├── Advertising
├── Help/Support
├── Admin/RH Center
└── Developer Center

Backend
├── Auth
├── Workspace
├── Users
├── Advertising
├── Payments
├── Billing
├── Ledger
├── Fiscal
├── HR
├── Moderation
├── Audit
├── Notifications
└── Feature Flags

Infrastructure
├── Firebase Authentication
├── Firestore
├── Cloud Functions 2nd Gen
├── Cloud Storage
├── App Check
├── Cloud Scheduler
├── Cloud Messaging
└── Hosting

External
├── Stripe / Stripe Connect
├── GitHub
├── APIs cadastrais
├── Provider fiscal/NFS-e
└── outros providers homologados
```

---

## 4. Firebase

### Authentication
Responsável por identidade, sessão, provedores OAuth e MFA quando habilitado.

### Firestore
Persistência de dados transacionais e operacionais.

### Cloud Functions 2nd Gen
Backend de aplicação, webhooks, jobs, validações e integrações.

### Storage
Imagens, documentos, anexos e artefatos autorizados.

### App Check
Proteção adicional contra clientes não autorizados.

### Scheduler
Jobs de conciliação, expiração, manutenção, relatórios e verificações.

### Messaging
Notificações push.

---

## 5. Estrutura frontend

```text
src/
├── app/
├── layouts/
│   ├── PublicLayout/
│   ├── SocialLayout/
│   ├── AdminLayout/
│   └── DeveloperLayout/
├── modules/
│   ├── auth/
│   ├── workspace/
│   ├── social/
│   ├── advertising/
│   ├── payments/
│   ├── billing/
│   ├── ledger/
│   ├── fiscal/
│   ├── hr/
│   ├── moderation/
│   ├── support/
│   ├── developer/
│   └── audit/
├── components/
├── hooks/
├── providers/
├── services/
├── types/
└── styles/
```

Cada componente:

```text
Component/
├── Component.tsx
├── Component.css
├── Component.types.ts
├── Component.test.tsx
└── index.ts
```

O CSS deve ser importado pelo próprio componente. A página não deve concentrar CSS de dezenas de componentes.

---

## 6. Layout

O layout deve conter apenas estrutura:

```text
Layout
├── Header
├── Sidebar
├── Main
└── RightRail
```

A rota decide qual página renderizar.

A página decide quais features utilizar.

A feature decide quais componentes utilizar.

```text
Router
  ↓
Page
  ↓
Feature
  ↓
Component
  ↓
Hook/Service
  ↓
Backend
```

---

## 7. Developer Center

Módulo técnico separado do Admin/RH.

### Funções

- Dashboard técnico.
- Status dos ambientes.
- GitHub.
- Branches.
- Pull Requests.
- VS Code web.
- OpenCode.
- Terminal controlado.
- Firebase.
- Firestore.
- Functions.
- Storage.
- Logs.
- Erros.
- Build.
- Testes.
- Lint.
- Typecheck.
- Feature Flags.
- Webhooks.
- Jobs.
- APIs.
- Secrets metadata.
- Deployments.
- Auditoria.

### Terminal

O terminal nunca deve possuir autorização implícita para produção.

Fluxo recomendado:

```text
Developer
 ↓
Development Workspace
 ↓
Branch
 ↓
Command Policy
 ↓
Tests
 ↓
Build
 ↓
PR
 ↓
Review
 ↓
Deploy
```

A `main` e os ambientes de produção devem ser protegidos por GitHub/CI/CD.

---

## 8. Admin/RH Center

O painel administrativo será o centro operacional:

- Dashboard.
- Usuários.
- Workspaces.
- Empresas.
- Verificações.
- Social.
- Moderação.
- Anúncios.
- Contas de anúncio.
- Pagamentos.
- Billing.
- Ledger.
- Fiscal.
- Conciliação.
- Documentos.
- RH.
- Permissões.
- Segurança.
- Auditoria.
- Configurações.
- Feature Flags.

O módulo RH permanece dentro do Admin/RH, mas com permissões próprias.

---

## 9. Workspace e validação empresarial

Fluxo:

```text
Cadastro
 ↓
Criar Workspace
 ↓
CPF/CNPJ
 ↓
Dados empresariais
 ↓
Validação cadastral
 ↓
VERIFIED / PENDING / REVIEW_REQUIRED
 ↓
Ativação
```

A integração cadastral deve ser implementada através de adapter/provedor homologado. Não deve existir dependência direta espalhada pelo frontend.

---

## 10. Advertising Account

A conta de anúncios é uma entidade de negócio independente:

```text
AdvertisingAccount
├── id
├── workspace_id
├── owner_id
├── stripe_reference
├── status
├── currency
├── balance_state
├── compliance_state
├── created_at
├── closed_at
└── metadata
```

Estados sugeridos:

```text
PENDING
ACTIVE
RESTRICTED
SUSPENDED
FROZEN
CLOSURE_PENDING
CLOSED
```

### Regra solicitada

Uma conta de anúncios pode ser encerrada para finalizar seu ciclo operacional e permitir o tratamento do saldo elegível conforme as regras da FLOW, Stripe, legislação e contrato.

Importante: **não implementar "cancelar para sacar" como uma exigência da Stripe sem confirmação contratual.** Essa é uma regra de produto da FLOW e deve ser juridicamente e financeiramente validada.

Ao fechar uma conta:

```text
ACTIVE
 ↓
CLOSURE_REQUESTED
 ↓
COMPLIANCE_CHECK
 ↓
PENDING_BALANCE_RECONCILIATION
 ↓
ELIGIBLE_FOR_PAYOUT / REFUND
 ↓
CLOSED
```

Uma nova conta de anúncios recebe novo identificador e novo ciclo de controle.

Nunca reutilizar o saldo ou histórico da conta antiga como se fosse a mesma conta.

---

## 11. Dinheiro bloqueado por abuso/fraude/compliance

O sistema deve separar:

```text
balance_available
balance_pending
balance_reserved
balance_restricted
```

Um anúncio suspeito não deve simplesmente apagar o dinheiro.

Exemplo:

```text
Campaign
 ↓
Violation
 ↓
Moderation Case
 ↓
Account RESTRICTED
 ↓
Funds RESTRICTED
```

O valor fica contabilizado no ledger e associado ao motivo.

O desbloqueio ou reembolso/pagamento depende da decisão de compliance e das regras aplicáveis.

A Stripe informa que atividades restritas podem exigir due diligence adicional e que saldos podem ser retidos para cobrir possíveis contestações. Portanto, o FLOW deve tratar retenção como estado controlado, não como saldo perdido. 

---

## 12. Moderação

Pipeline:

```text
Create Ad
 ↓
Content Validation
 ↓
Policy Engine
 ↓
Automated Checks
 ↓
Human Review when required
 ↓
APPROVED / REJECTED / REVIEW
```

Categorias:

- conteúdo ilegal;
- fraude;
- impersonação;
- violência ilegal;
- discriminação proibida;
- produtos/serviços restritos;
- conteúdo sexual proibido;
- spam;
- malware;
- práticas enganosas;
- categorias internas de risco.

A lista real deve ser versionada e alinhada às políticas da FLOW, legislação e provedores de pagamento.

A Stripe mantém uma lista de atividades proibidas/restritas e deixa claro que a lista é representativa e que determinadas categorias dependem de aprovação/due diligence. 

---

## 13. Stripe

Integração isolada:

```text
StripeAdapter
├── Customer
├── Payment
├── Checkout
├── Billing
├── Connect
├── Balance
├── Refund
├── Dispute
├── Payout
└── Webhook
```

A Stripe Connect oferece recursos para plataformas, incluindo pagamentos, repasses, reembolsos e contestações.

A FLOW deve manter uma camada própria:

```text
Stripe
 ↓
Payment Adapter
 ↓
Payment Service
 ↓
Ledger
 ↓
Fiscal
 ↓
Advertising
```

Nunca acoplar componentes React diretamente à API Stripe secreta.

---

## 14. Webhooks

Todos os webhooks precisam de idempotência:

```text
WebhookEvent
├── provider
├── event_id
├── event_type
├── received_at
├── processed_at
├── status
├── payload_hash
└── error
```

Fluxo:

```text
Stripe
 ↓
HTTPS Function
 ↓
Signature Verification
 ↓
Idempotency Check
 ↓
Transaction
 ↓
Domain Event
```

Nunca confiar somente no frontend para confirmar pagamento.

---

## 15. Ledger

O Ledger é a fonte interna para rastrear movimentos:

```text
LedgerEntry
├── id
├── workspace_id
├── advertising_account_id
├── transaction_id
├── type
├── direction
├── amount
├── currency
├── status
├── source
├── external_reference
├── created_at
└── metadata
```

Tipos:

```text
DEPOSIT
PAYMENT
FEE
TAX
REFUND
CHARGEBACK
PAYOUT
RESERVE
RELEASE
AD_SPEND
ADJUSTMENT
```

Nunca alterar um lançamento histórico. Correções devem gerar novos lançamentos.

---

## 16. Fiscal

Módulo independente:

```text
fiscal/
├── FiscalProfile
├── TaxRule
├── FiscalDocument
├── Invoice
├── NfseProvider
├── FiscalEvent
└── FiscalReconciliation
```

A alíquota não deve ser hardcoded no frontend.

O cálculo deve considerar configuração fiscal vigente e classificação do serviço, com homologação contábil.

A Stripe informa que suas próprias tarifas no Brasil possuem tratamento tributário específico e que não emite NFS-e aos titulares brasileiros pelas tarifas desde 2022; isso não significa que a FLOW deixe de ter suas próprias obrigações fiscais sobre os serviços que presta.

---

## 17. Conciliação

```text
Stripe Events
      ↓
FLOW Transactions
      ↓
Ledger
      ↓
Reconciliation
      ↓
Fiscal
      ↓
Accounting Export
```

Diferenças devem gerar `RECONCILIATION_EXCEPTION`.

---

## 18. Auditoria

Toda operação crítica gera evento:

```text
AuditEvent
├── actor_id
├── actor_role
├── action
├── resource
├── resource_id
├── before
├── after
├── timestamp
├── source
├── result
└── correlation_id
```

Operações obrigatoriamente auditadas:

- alteração de permissão;
- bloqueio;
- desbloqueio;
- suspensão;
- fechamento de conta de anúncio;
- movimentação financeira;
- alteração fiscal;
- emissão/cancelamento de documento;
- alteração de feature flag;
- execução de comando administrativo;
- deploy;
- alteração de configuração.

---

## 19. Feature Flags

```text
FeatureFlag
├── key
├── enabled
├── environment
├── rollout
├── changed_by
├── changed_at
└── reason
```

Um módulo com erro pode ser desativado sem remover código.

Exemplo:

```text
advertising.enabled = false
```

A UI deve apresentar estado `MODULE_DISABLED`.

---

## 20. RBAC

Papéis:

```text
OWNER
MASTER_ADMIN
ADMIN
HR_MANAGER
FINANCE_MANAGER
MODERATOR
DEVELOPER
SUPPORT
ANALYST
USER
```

Permissões granulares:

```text
advertising.read
advertising.write
advertising.moderate
advertising.close

finance.read
finance.reconcile

fiscal.read
fiscal.issue
fiscal.cancel

developer.read
developer.terminal
developer.repository
developer.deploy

hr.read
hr.write
```

Autorização deve ser validada no backend.

---

## 21. PWA

Obrigatório:

- Web App Manifest.
- Ícones oficiais.
- display standalone.
- theme color.
- responsive breakpoints.
- service worker.
- estratégia offline.
- instalação em Android/iOS/desktop quando suportado.
- metadados.
- deep links.
- telas de fallback.

---

## 22. Estados de UI

Cada módulo precisa implementar:

```text
loading
empty
error
success
disabled
unauthorized
forbidden
offline
retry
```

---

## 23. Testes

### Unitários
Domínio, regras, reducers, validators.

### Integração
Firebase, Stripe mock/test mode, webhooks, adapters.

### E2E
Cadastro → Workspace → anúncio → pagamento → webhook → ledger → moderação.

### Segurança
Rules, RBAC, App Check, autorização.

### Build
```text
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

---

## 24. Política de produção

Proibido:

- editar produção diretamente pelo terminal;
- push direto na main;
- armazenar secret no frontend;
- usar mock como fonte de produção;
- alterar ledger histórico;
- ignorar webhook;
- confiar em `localStorage` para autorização;
- colocar toda a aplicação em uma página gigante.

Obrigatório:

- branch;
- PR;
- testes;
- CI;
- revisão;
- auditoria;
- deploy controlado.

---

## 25. Critério de pronto

Um módulo só é considerado pronto quando possui:

```text
UI
+ Components
+ CSS
+ Types
+ Hooks
+ Service
+ Backend
+ Firebase
+ Security Rules
+ Tests
+ Error States
+ Audit
+ Documentation
```

---

## 26. Observação sobre os 350 layouts

O catálogo exato de 350 telas, incluindo nomes, IDs, imagens, rotas e correspondência visual, deve ser cruzado com os arquivos oficiais do catálogo.

Os arquivos anteriormente enviados não estão mais disponíveis nesta sessão. Portanto este documento define a engenharia-base e o modelo de inventário, mas não afirma que cada uma das 350 telas já foi auditada visualmente.

Para fechar o inventário pixel-a-pixel, reanexar:

```text
FLOW_CATALOGO_350_TELAS_DESKTOP_LIGHT/
docs/INVENTARIO_350_TELAS.*
FLOW_CATALOGO_MANIFESTO.txt
```

---

## 27. Fontes técnicas consultadas

- Stripe Connect: plataforma para pagamentos, repasses, reembolsos e contestações.
- Stripe Brasil — atividades proibidas/restritas.
- Stripe Brasil — tributação das tarifas.
- Stripe Tax.
- Firebase Cloud Functions.
- Firebase App Check.

Este documento não substitui validação jurídica, contábil, fiscal ou contratual.
